angular.module("app", []).controller("HelloWorldCtrl", function($scope) {  
    $scope.operator='';
    $scope.inOperation = false;
    $scope.num1 = 0;
    $scope.init=function(){
        $scope.result="0";
    };
    $scope.press=function(val){
        if($scope.result == "0") {
            $scope.result = val;
         } else {
            $scope.num2=val;
            $scope.result += val;
         }
        console.log($scope.result);
    };
    
   
   
   
    $scope.operatr=function(op){
        if($scope.operator!=''){
            alert("One Operator is already present")
        }
        else{
            $scope.num1 = String($scope.result);
            $scope.operator=op;
            $scope.result +=op;
        }
        
    }
    $scope.calculate=function(){
        
        if($scope.result.length > $scope.num1.length+1){
            if ($scope.operator == '+') {
                $scope.result=Number($scope.num1) + Number($scope.num2);
            }
            if ($scope.operator == '-') {
                $scope.result=Number($scope.num1) - Number($scope.num2);
            }
            if ($scope.operator == '*') {
                $scope.result=Number($scope.num1) * Number($scope.num2);
            }
            if ($scope.operator == '/') {
                $scope.result=Number($scope.num1) / Number($scope.num2);
            }
            $scope.num1= $scope.result;
            $scope.operator='';
        }
    };
    $scope.clr=function(){
        $scope.result="0";
        $scope.num1 ="0";
        $scope.num2 ="0";
        $scope.operator='';
        $scope.inOperation = false;
    }
    
    $scope.init();
});