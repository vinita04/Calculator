angular.module("app", []).controller("HelloWorldCtrl", function($scope) {  

    //$scope.result=0;
    //$scope.expression='';
    $scope.init=function(){
        $scope.result='';
    };
    $scope.press=function(val){
        
        $scope.result+=val;
        console.log($scope.result);
    };
    $scope.calculate=function(){
        $scope.result=eval($scope.result);
    };
    $scope.clr=function(){
        $scope.result='';
    }
    
    $scope.init();
});